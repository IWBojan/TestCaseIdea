package com.company;

public class NewTests {

    public NewTests() {
    }

    private  int a = 15;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }
}
