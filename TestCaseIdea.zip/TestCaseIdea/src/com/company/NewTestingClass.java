package com.company;

public class NewTestingClass {
    public static void main(String[] args) {
        System.out.println("testing");

        System.out.println("GIT");

        int a=5;
    }
}
