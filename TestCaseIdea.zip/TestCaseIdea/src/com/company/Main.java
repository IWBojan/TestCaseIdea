package com.company;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

class HelloWorld{

    public static void main(String[] args) {
        System.out.println("Hello Ivana How are you!!!!!");

        System.out.println("Hello Ivana");
        String name = "Ivana";
        System.out.println("TEst, adding changes");

        System.out.println("testing is fun");
        System.out.println("TEst");

        System.out.println("new tests added");

        System.out.println("another test added");
        }

    }

