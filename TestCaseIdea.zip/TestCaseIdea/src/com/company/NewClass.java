package com.company;

public class NewClass {

    public static void main(String[] args) {
        System.out.println("Learning GIT is fun..");
        System.out.println("Hellooo again!");

        int b = 20;

        int a = 15;

        String name = "Mimi11";
    }
}
